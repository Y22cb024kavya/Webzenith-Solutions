(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/apps_web_94496af7._.js",
  "static/chunks/6a1b1_@supabase_realtime-js_dist_module_ba3fb7a1._.js",
  "static/chunks/74b0b_@supabase_storage-js_dist_module_9a783542._.js",
  "static/chunks/2ca13_@supabase_auth-js_dist_module_cb6e2d66._.js",
  "static/chunks/37e87_zod_v4_9728400a._.js",
  "static/chunks/bb4e9_@radix-ui_react-select_dist_index_mjs_71071433._.js",
  "static/chunks/node_modules__pnpm_86fb8d7a._.js"
],
    source: "dynamic"
});
