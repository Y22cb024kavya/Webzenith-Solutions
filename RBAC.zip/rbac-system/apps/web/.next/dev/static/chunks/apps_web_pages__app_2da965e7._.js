(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/243b6_next_dist_compiled_3b11b429._.js",
  "static/chunks/243b6_next_dist_shared_lib_2fe28354._.js",
  "static/chunks/243b6_next_dist_client_7d803322._.js",
  "static/chunks/243b6_next_dist_ee8ecac4._.js",
  "static/chunks/243b6_next_app_ad188198.js",
  "static/chunks/[next]_entry_page-loader_ts_7447b2d5._.js",
  "static/chunks/76102_react-dom_44795136._.js",
  "static/chunks/node_modules__pnpm_7136f466._.js",
  "static/chunks/[root-of-the-server]__67058656._.js"
],
    source: "entry"
});
