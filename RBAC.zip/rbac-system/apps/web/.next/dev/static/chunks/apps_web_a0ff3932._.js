(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_d4d60b6e._.js",
  "static/chunks/243b6_next_dist_compiled_react-dom_f6e69f99._.js",
  "static/chunks/243b6_next_dist_compiled_react-server-dom-turbopack_5fc56eba._.js",
  "static/chunks/243b6_next_dist_compiled_next-devtools_index_332bb9e8.js",
  "static/chunks/243b6_next_dist_compiled_47bf9190._.js",
  "static/chunks/243b6_next_dist_client_15f10f3f._.js",
  "static/chunks/243b6_next_dist_85407b7c._.js",
  "static/chunks/69652_@swc_helpers_cjs_679851cc._.js"
],
    source: "entry"
});
