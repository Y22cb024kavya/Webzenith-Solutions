__turbopack_load_page_chunks__("/_error", [
  "static/chunks/243b6_next_dist_compiled_3b11b429._.js",
  "static/chunks/243b6_next_dist_shared_lib_a689e4c1._.js",
  "static/chunks/243b6_next_dist_client_7d803322._.js",
  "static/chunks/243b6_next_dist_7338056b._.js",
  "static/chunks/243b6_next_error_19822a5e.js",
  "static/chunks/[next]_entry_page-loader_ts_1dae9577._.js",
  "static/chunks/76102_react-dom_44795136._.js",
  "static/chunks/node_modules__pnpm_7136f466._.js",
  "static/chunks/[root-of-the-server]__4ed92dca._.js",
  "static/chunks/apps_web_pages__error_2da965e7._.js",
  "static/chunks/turbopack-apps_web_pages__error_a144dab3._.js"
])
