(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/6a1b1_@supabase_realtime-js_dist_module_ba3fb7a1._.js",
  "static/chunks/74b0b_@supabase_storage-js_dist_module_9a783542._.js",
  "static/chunks/2ca13_@supabase_auth-js_dist_module_cb6e2d66._.js",
  "static/chunks/37e87_zod_v4_9728400a._.js",
  "static/chunks/node_modules__pnpm_8209fdcd._.js",
  "static/chunks/apps_web_d619216d._.js"
],
    source: "dynamic"
});
