(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/apps_web_app_971b7504._.css",
  "static/chunks/node_modules__pnpm_de3bd84d._.js",
  "static/chunks/apps_web_f8044150._.js"
],
    source: "dynamic"
});
