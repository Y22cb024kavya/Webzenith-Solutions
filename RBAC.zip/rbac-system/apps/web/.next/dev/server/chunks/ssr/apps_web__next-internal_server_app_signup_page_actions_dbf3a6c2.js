module.exports = [
"[project]/apps/web/.next-internal/server/app/signup/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
}),
];

//# sourceMappingURL=apps_web__next-internal_server_app_signup_page_actions_dbf3a6c2.js.map