import type { Metadata } from "next";
import localFont from "next/font/local"; // <--- Ensure this is imported
import "./globals.css";
import { Navbar } from "@/components/navbar"; 
import { createClient } from "@/utils/supabase/server"; 

// --- THESE WERE MISSING ---
const geistSans = localFont({
  src: "./fonts/GeistVF.woff",
  variable: "--font-geist-sans",
});
const geistMono = localFont({
  src: "./fonts/GeistMonoVF.woff",
  variable: "--font-geist-mono",
});
// ---------------------------

export const metadata: Metadata = {
  title: "RBAC System",
  description: "Webzenith Solutions",
};

export default async function RootLayout({ children }: { children: React.ReactNode }) {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  
  let roleName = "";
  
  if (user) {
    const { data: userRole } = await supabase
      .from('user_roles')
      .select('roles ( name )')
      .eq('user_id', user.id)
      .single();
    roleName = userRole?.roles ? (userRole.roles as any).name : '';
  }

  return (
    <html lang="en">
      <body className={`${geistSans.variable} ${geistMono.variable} bg-slate-50`}>
        <Navbar role={roleName} /> 
        <main className="pt-20">
          {children}
        </main>
      </body>
    </html>
  );
}