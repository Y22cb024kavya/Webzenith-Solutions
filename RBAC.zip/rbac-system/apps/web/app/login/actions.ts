'use server'

import { redirect } from 'next/navigation'
import { createClient } from '@/utils/supabase/server'

export async function login(formData: FormData) {
  const supabase = await createClient()

  const email = formData.get('email') as string
  const password = formData.get('password') as string

  // 1. REAL SUPABASE LOGIN
  const { error } = await supabase.auth.signInWithPassword({
    email,
    password,
  })

  if (error) {
    // In a real app, you would return this error to the UI
    console.error("Login Failed:", error.message)
    return { error: "Invalid login credentials" }
  }

  // 2. SUCCESS
  redirect('/dashboard')
}