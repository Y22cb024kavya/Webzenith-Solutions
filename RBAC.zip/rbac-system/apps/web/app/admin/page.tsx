'use client'

import { useState, useEffect } from "react";
import { createClient } from "@/utils/supabase/client";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import PermissionMatrix from "./permission-matrix";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Plus, User, Loader2 } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useRouter } from "next/navigation";
import { adminCreateUser, getAllUsers } from "./actions"; 
import { Role, Permission, User as UserType } from "@/types"; 

export default function AdminPage() {
  const supabase = createClient();
  const router = useRouter();
  const [loading, setLoading] = useState(true);

  const [roles, setRoles] = useState<Role[]>([]);
  const [permissions, setPermissions] = useState<Permission[]>([]);
  const [assignments, setAssignments] = useState<any[]>([]);
  const [users, setUsers] = useState<UserType[]>([]);

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      
      // 1. Fetch Public Data
      const { data: rolesData } = await supabase.from('roles').select('*').order('name');
      const { data: permData } = await supabase.from('permissions').select('*').order('slug');
      const { data: assignData } = await supabase.from('role_permissions').select('*');
      const { data: userRoleData } = await supabase.from('user_roles').select('*');

      // 2. Fetch Secure User Emails
      const authUsers = await getAllUsers();

      setRoles(rolesData || []);
      setPermissions(permData || []);
      setAssignments(assignData || []);
      
      // 3. Merge and Clean Data
      const mergedUsers: UserType[] = authUsers.map(u => {
        const assignedRole = userRoleData?.find(r => r.user_id === u.id);
        return {
          id: u.id,
          email: u.email || "", // <--- FIX 1: Ensure email is never null
          role_id: assignedRole?.role_id || null
        };
      });
      
      setUsers(mergedUsers);
      setLoading(false);
    };

    fetchData();
  }, []);

  // --- ACTIONS ---
  const handleCreateRole = async () => {
    const roleName = window.prompt("Enter new role name:");
    if (!roleName) return;
    const { data } = await supabase.from('roles').insert({ name: roleName }).select().single();
    if (data) {
      setRoles([...roles, data]);
      router.refresh();
    }
  };

  const handleAddUser = async () => {
    const email = window.prompt("Enter email for new user (Default password: password123):");
    if (!email) return;
    const result = await adminCreateUser(email);
    if (result.success) {
      alert("User created! Refreshing list...");
      window.location.reload();
    } else {
      alert("Error creating user: " + result.error);
    }
  };

  const handleToggle = async (roleId: string, permId: string, isChecked: boolean) => {
    if (isChecked) {
      setAssignments([...assignments, { role_id: roleId, permission_id: permId }]);
      await supabase.from('role_permissions').insert({ role_id: roleId, permission_id: permId });
    } else {
      setAssignments(assignments.filter(a => !(a.role_id === roleId && a.permission_id === permId)));
      await supabase.from('role_permissions').delete().match({ role_id: roleId, permission_id: permId });
    }
    router.refresh();
  };

  const handleRoleStatus = async (roleId: string, status: boolean) => {
    setRoles(roles.map(r => r.id === roleId ? { ...r, is_enabled: status } : r));
    await supabase.from('roles').update({ is_enabled: status }).eq('id', roleId);
  };

  const handleRenameRole = async (roleId: string, newName: string) => {
    setRoles(roles.map(r => r.id === roleId ? { ...r, name: newName } : r));
    await supabase.from('roles').update({ name: newName }).eq('id', roleId);
  };

  const handleAssignRole = async (userId: string, newRoleId: string) => {
    setUsers(users.map(u => u.id === userId ? { ...u, role_id: newRoleId } : u));
    await supabase.from('user_roles').upsert({ user_id: userId, role_id: newRoleId }, { onConflict: 'user_id' });
    router.refresh();
  };

  if (loading) return <div className="flex h-screen items-center justify-center"><Loader2 className="animate-spin" /></div>;

  return (
    <div className="p-8 max-w-[1400px] mx-auto">
      <div className="flex justify-between items-center mb-6">
        <div className="flex items-center gap-4">
          <h1 className="text-3xl font-bold tracking-tight">Access Control</h1>
          <Badge className="bg-green-600 text-white">Live Database Mode</Badge>
        </div>
      </div>

      <Tabs defaultValue="matrix" className="w-full">
        <TabsList className="mb-4">
          <TabsTrigger value="matrix">Role Matrix</TabsTrigger>
          <TabsTrigger value="users">User Management</TabsTrigger>
        </TabsList>

        <TabsContent value="matrix">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle>Role-Permission Matrix</CardTitle>
                <CardDescription>Manage what each role can do.</CardDescription>
              </div>
              <Button onClick={handleCreateRole} size="sm" className="gap-2">
                <Plus className="w-4 h-4" /> Create Role
              </Button>
            </CardHeader>
            <CardContent>
              <PermissionMatrix 
                roles={roles} 
                permissions={permissions} 
                existingAssignments={assignments}
                onToggle={handleToggle}
                onRoleStatusChange={handleRoleStatus}
                onRenameRole={handleRenameRole}
              />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="users">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle>User Assignment</CardTitle>
                <CardDescription>Assign roles to registered users.</CardDescription>
              </div>
              <Button onClick={handleAddUser} size="sm" className="gap-2">
                <User className="w-4 h-4" /> Add User
              </Button>
            </CardHeader>
            <CardContent>
              <div className="border rounded-lg">
                {users.map((user) => (
                  <div key={user.id} className="flex items-center justify-between p-4 border-b last:border-0 hover:bg-slate-50">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full bg-slate-200 flex items-center justify-center font-bold text-slate-600">
                        {/* --- FIX 2: Use Safe Optional Chaining --- */}
                        {user.email?.[0]?.toUpperCase() || "U"}
                      </div>
                      <div className="flex flex-col">
                        <span className="font-medium text-slate-900">{user.email || "Unknown User"}</span>
                        <span className="font-mono text-[10px] text-slate-400">{user.id}</span>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <Select 
                        value={user.role_id || "unassigned"} 
                        onValueChange={(val) => handleAssignRole(user.id, val)}
                      >
                        <SelectTrigger className="w-[180px]">
                          <SelectValue placeholder="Select a role" />
                        </SelectTrigger>
                        <SelectContent>
                          {roles.map(r => (
                            <SelectItem key={r.id} value={r.id}>
                              {r.name} {!r.is_enabled && "(Disabled)"}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}