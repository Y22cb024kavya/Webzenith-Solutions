'use server'

import { createClient } from '@supabase/supabase-js'
import { revalidatePath } from 'next/cache'

// 1. Setup Admin Client with the SECRET Key
// This allows us to bypass security to create users instantly
const supabaseAdmin = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!,
  {
    auth: {
      autoRefreshToken: false,
      persistSession: false
    }
  }
)

export async function adminCreateUser(email: string) {
  console.log(`[ADMIN] Attempting to create real user: ${email}`);

  // 2. Create User in Supabase Auth (Real Database)
  const { data: authData, error: authError } = await supabaseAdmin.auth.admin.createUser({
    email: email,
    password: 'password123', // Default password
    email_confirm: true      // Auto-verify them so they can login immediately
  });

  if (authError) {
    console.error("❌ Auth Error:", authError.message);
    return { success: false, error: authError.message };
  }

  // 3. Create Entry in Public Database (Real Database)
  if (authData.user) {
    // Find 'User' role ID
    const { data: roleData } = await supabaseAdmin
      .from('roles')
      .select('id')
      .eq('name', 'User')
      .single();

    if (roleData) {
      const { error: dbError } = await supabaseAdmin
        .from('user_roles')
        .insert({
          user_id: authData.user.id,
          role_id: roleData.id
        });
      
      if (dbError) {
        console.error("❌ DB Error:", dbError.message);
      } else {
        console.log("✅ User and Role successfully added to Supabase!");
      }
    }
  }

  revalidatePath('/admin');
  return { success: true };
}

// --- NEW FUNCTION: Fetch All User Emails ---
export async function getAllUsers() {
  // Use the Admin Client to fetch the secure user list
  const { data, error } = await supabaseAdmin.auth.admin.listUsers();
  
  if (error) {
    console.error("Error fetching users:", error.message);
    return [];
  }

  // Return just the ID and Email to the frontend
  return data.users.map(u => ({
    id: u.id,
    email: u.email
  }));
}