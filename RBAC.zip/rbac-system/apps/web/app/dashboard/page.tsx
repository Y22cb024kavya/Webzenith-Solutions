export const dynamic = 'force-dynamic'; // <--- THIS FIXES THE CACHING ISSUE

import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Shield, User, Activity, Briefcase } from "lucide-react";
import { createClient } from "@/utils/supabase/server";
import { redirect } from "next/navigation";
import { LeadsManager } from "@/components/leads-manager";
import { getUserPermissions } from "@/utils/permissions";

export default async function Dashboard() {
  const supabase = await createClient();

  // 1. GET REAL USER
  const { data: { user }, error } = await supabase.auth.getUser();
  if (error || !user) redirect("/login");

  // 2. GET REAL ROLE
  const { data: userRole } = await supabase
    .from('user_roles')
    .select('roles ( name )')
    .eq('user_id', user.id)
    .single();

  const roleName = userRole?.roles ? (userRole.roles as any).name : 'No Role';
  const permissions = await getUserPermissions(); // Fetch perms to pass to client

  // FETCH LEADS DATA
  const { data: leads } = await supabase.from('leads').select('*').order('created_at', { ascending: false });

  // Helper to color the badges based on role
  const getRoleColor = (role: string) => {
    if (role === 'Admin') return "bg-blue-600";
    if (role === 'Sales Manager') return "bg-emerald-600";
    return "bg-slate-500";
  };

  return (
    <div className="max-w-7xl mx-auto p-8 space-y-8">
      
      {/* Header & Stats */}
      <div className="flex flex-col gap-1">
        <h1 className="text-3xl font-bold tracking-tight text-slate-900">Dashboard Overview</h1>
        <p className="text-slate-500">Welcome back, {user.email}</p>
      </div>

      {/* Stats Grid */}
      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-slate-600">User Identity</CardTitle>
            <User className="h-4 w-4 text-slate-400" />
          </CardHeader>
          <CardContent>
            <div className="text-xl font-bold truncate">{user.email?.split('@')[0]}</div>
            <p className="text-xs text-muted-foreground font-mono mt-1">ID: {user.id.slice(0, 8)}...</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-slate-600">Access Level</CardTitle>
            <Shield className="h-4 w-4 text-slate-400" />
          </CardHeader>
          <CardContent>
            <Badge className={`${getRoleColor(roleName)} hover:${getRoleColor(roleName)} text-sm px-3 py-1`}>
              {roleName}
            </Badge>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-slate-600">System Status</CardTitle>
            <Activity className="h-4 w-4 text-green-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">Online</div>
            <p className="text-xs text-muted-foreground mt-1">Connected to Supabase</p>
          </CardContent>
        </Card>
      </div>

      {/* Main Content Area */}
      <div className="grid gap-8 md:grid-cols-1">
        <Card>
          <CardHeader>
            <div className="flex items-center gap-2">
              <Briefcase className="w-6 h-6 text-blue-600" />
              <CardTitle>Leads CRM</CardTitle>
            </div>
            <CardDescription>Real-time data. Actions are enabled based on your role.</CardDescription>
          </CardHeader>
          <CardContent>
            {/* THE REAL CRUD MANAGER */}
            <LeadsManager leads={leads || []} permissions={permissions} />
          </CardContent>
        </Card>
      </div>
    </div>
  );
}