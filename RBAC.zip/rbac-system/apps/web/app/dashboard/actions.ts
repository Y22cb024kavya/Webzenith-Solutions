'use server'

import { createClient } from "@/utils/supabase/server";
import { getUserPermissions } from "@/utils/permissions";
import { revalidatePath } from "next/cache";

// --- 1. CREATE ---
export async function createLead(formData: FormData) {
  const permissions = await getUserPermissions();
  if (!permissions.includes('leads.create')) {
    return { success: false, error: "Access Denied: Missing 'leads.create' permission" };
  }

  const supabase = await createClient();
  const companyName = formData.get('companyName') as string;
  const value = formData.get('value') as string;

  await supabase.from('leads').insert({ 
    company_name: companyName, 
    value: parseInt(value),
    status: 'New'
  });

  revalidatePath('/dashboard');
  return { success: true };
}

// --- 2. UPDATE ---
export async function updateLeadStatus(leadId: string, newStatus: string) {
  const permissions = await getUserPermissions();
  if (!permissions.includes('leads.update')) {
    return { success: false, error: "Access Denied: Missing 'leads.update' permission" };
  }

  const supabase = await createClient();
  await supabase.from('leads').update({ status: newStatus }).eq('id', leadId);

  revalidatePath('/dashboard');
  return { success: true };
}

// --- 3. DELETE ---
export async function deleteLead(leadId: string) {
  const permissions = await getUserPermissions();
  // Reusing 'users.delete' for this high-risk action demonstration
  if (!permissions.includes('users.delete')) { 
    return { success: false, error: "Access Denied: Missing 'users.delete' permission" };
  }

  const supabase = await createClient();
  await supabase.from('leads').delete().eq('id', leadId);

  revalidatePath('/dashboard');
  return { success: true };
}