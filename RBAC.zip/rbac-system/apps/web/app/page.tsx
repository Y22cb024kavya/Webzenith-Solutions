import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Shield, Lock, Users, Fingerprint } from "lucide-react"; 

export default function Page() {
  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="flex flex-col items-center justify-center py-24 text-center bg-slate-50 space-y-8">
        <div className="bg-blue-100 p-4 rounded-full">
          <Shield className="w-12 h-12 text-blue-600" />
        </div>
        <div className="space-y-4 max-w-2xl">
          <h1 className="text-4xl font-extrabold tracking-tight lg:text-5xl text-slate-900">
            Secure Role-Based Access Control
          </h1>
          <p className="text-xl text-slate-600">
            A complete permission management system built for Webzenith Solutions.
            Manage roles, assign permissions, and secure your application with ease.
          </p>
        </div>
        <div className="flex gap-4">
          <Link href="/login">
            <Button size="lg" className="px-8">Login to Demo</Button>
          </Link>
          <Link href="/admin">
            <Button variant="outline" size="lg">View Admin Matrix</Button>
          </Link>
        </div>
      </section>

      {/* Features Grid */}
      <section className="py-16 px-8 max-w-6xl mx-auto grid gap-8 md:grid-cols-3">
        <Card>
          <CardHeader>
            <Users className="w-8 h-8 text-blue-500 mb-2" />
            <CardTitle>Role Management</CardTitle>
          </CardHeader>
          <CardContent className="text-slate-600">
            Create unlimited custom roles. Enable or disable them instantly to control system access.
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <Lock className="w-8 h-8 text-blue-500 mb-2" />
            <CardTitle>Granular Permissions</CardTitle>
          </CardHeader>
          <CardContent className="text-slate-600">
            Fine-grained control over Entities (Users, Leads) and Operations (Create, Read, Update, Delete).
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <Fingerprint className="w-8 h-8 text-blue-500 mb-2" />
            <CardTitle>Secure Enforcement</CardTitle>
          </CardHeader>
          <CardContent className="text-slate-600">
            Full security implementation with frontend UI guards and backend server action validation.
          </CardContent>
        </Card>
      </section>
    </div>
  );
}