'use server'

import { revalidatePath } from 'next/cache'
import { redirect } from 'next/navigation'
import { createClient } from '@/utils/supabase/server'

export async function signup(formData: FormData) {
  const supabase = await createClient()

  const email = formData.get('email') as string
  const password = formData.get('password') as string
  const fullName = formData.get('fullName') as string

  console.log("--- STARTING REAL SIGNUP ---");

  // 1. Create User in Supabase Auth
  // This stores the credentials (Email/Password) securely
  const { data, error } = await supabase.auth.signUp({
    email,
    password,
    options: {
      data: { full_name: fullName },
    },
  })

  if (error) {
    console.error("❌ Signup Failed in Auth:", error.message)
    return { error: error.message }
  }

  console.log("✅ Auth User Created ID:", data.user?.id);

  // 2. Assign Default Role in Public Table
  if (data.user) {
    // Get 'User' role ID
    const { data: roleData } = await supabase
      .from('roles')
      .select('id')
      .eq('name', 'User') 
      .single()

    if (roleData) {
      const { error: roleError } = await supabase.from('user_roles').insert({
        user_id: data.user.id,
        role_id: roleData.id
      })
      
      if (roleError) {
        console.error("⚠️ Role Assignment Failed:", roleError.message);
        // We don't stop here; the user exists, so let them login
      } else {
        console.log("✅ Role Assigned Successfully");
      }
    }
  }

  // 3. Force Auto-Login (To skip the login screen)
  await supabase.auth.signInWithPassword({
    email,
    password,
  })

  console.log("--- REDIRECTING TO DASHBOARD ---");
  revalidatePath('/', 'layout')
  redirect('/dashboard')
}